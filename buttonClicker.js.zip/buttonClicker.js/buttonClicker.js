function remove(element) {
    element.remove();
}

function logInOut(element) {
    element.innerText = "Logout";
}

function popup() {
    alert("Ninja was liked");
}